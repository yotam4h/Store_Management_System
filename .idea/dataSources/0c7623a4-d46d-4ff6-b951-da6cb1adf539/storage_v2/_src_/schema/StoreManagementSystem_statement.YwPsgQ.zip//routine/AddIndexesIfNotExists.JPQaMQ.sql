create
    definer = StoreManagementSystem_statement@`%` procedure AddIndexesIfNotExists()
BEGIN
    -- Users Table Indexes
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.statistics
        WHERE table_schema = DATABASE() AND table_name = 'Users' AND index_name = 'idx_users_username'
    ) THEN
        CREATE INDEX idx_users_username ON Users (username);
    END IF;

    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.statistics
        WHERE table_schema = DATABASE() AND table_name = 'Users' AND index_name = 'idx_users_branch_role'
    ) THEN
        CREATE INDEX idx_users_branch_role ON Users (branch_id, role);
    END IF;

    -- Branches Table Index
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.statistics
        WHERE table_schema = DATABASE() AND table_name = 'Branches' AND index_name = 'idx_branches_name'
    ) THEN
        CREATE INDEX idx_branches_name ON Branches (name);
    END IF;

    -- Employees Table Indexes
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.statistics
        WHERE table_schema = DATABASE() AND table_name = 'Employees' AND index_name = 'idx_employees_branch_role'
    ) THEN
        CREATE INDEX idx_employees_branch_role ON Employees (branch_id, role);
    END IF;

    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.statistics
        WHERE table_schema = DATABASE() AND table_name = 'Employees' AND index_name = 'idx_employees_full_name'
    ) THEN
        CREATE INDEX idx_employees_full_name ON Employees (full_name);
    END IF;

    -- Repeat for other indexes as needed...
END;

