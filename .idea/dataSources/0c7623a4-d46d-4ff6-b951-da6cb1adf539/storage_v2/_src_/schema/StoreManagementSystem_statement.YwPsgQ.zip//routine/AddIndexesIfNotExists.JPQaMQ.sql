create
    definer = StoreManagementSystem_statement@`%` procedure AddIndexesIfNotExists()
BEGIN
    -- Users Table Indexes
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.statistics
        WHERE table_schema = DATABASE() AND table_name = 'Users' AND index_name = 'idx_users_username'
    ) THEN
        CREATE INDEX idx_users_username ON Users (username);
    END IF;

    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.statistics
        WHERE table_schema = DATABASE() AND table_name = 'Users' AND index_name = 'idx_users_branch_role'
    ) THEN
        CREATE INDEX idx_users_branch_role ON Users (branch_id, role);
    END IF;

    -- Branches Table Index
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.statistics
        WHERE table_schema = DATABASE() AND table_name = 'Branches' AND index_name = 'idx_branches_name'
    ) THEN
        CREATE INDEX idx_branches_name ON Branches (name);
    END IF;

    -- Employees Table Indexes
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.statistics
        WHERE table_schema = DATABASE() AND table_name = 'Employees' AND index_name = 'idx_employees_branch_role'
    ) THEN
        CREATE INDEX idx_employees_branch_role ON Employees (branch_id, role);
    END IF;

    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.statistics
        WHERE table_schema = DATABASE() AND table_name = 'Employees' AND index_name = 'idx_employees_full_name'
    ) THEN
        CREATE INDEX idx_employees_full_name ON Employees (full_name);
    END IF;

    -- ChatSessions Table Indexes
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.statistics
        WHERE table_schema = DATABASE() AND table_name = 'ChatSessions' AND index_name = 'idx_chat_sessions_from_user'
    ) THEN
        CREATE INDEX idx_chat_sessions_from_user ON ChatSessions (from_user_id);
    END IF;

    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.statistics
        WHERE table_schema = DATABASE() AND table_name = 'ChatSessions' AND index_name = 'idx_chat_sessions_to_user'
    ) THEN
        CREATE INDEX idx_chat_sessions_to_user ON ChatSessions (to_user_id);
    END IF;

    -- ChatMessages Table Indexes
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.statistics
        WHERE table_schema = DATABASE() AND table_name = 'ChatMessages' AND index_name = 'idx_chat_messages_sender'
    ) THEN
        CREATE INDEX idx_chat_messages_sender ON ChatMessages (sender_id);
    END IF;

    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.statistics
        WHERE table_schema = DATABASE() AND table_name = 'ChatMessages' AND index_name = 'idx_chat_messages_session'
    ) THEN
        CREATE INDEX idx_chat_messages_session ON ChatMessages (chat_session_id);
    END IF;

    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.statistics
        WHERE table_schema = DATABASE() AND table_name = 'ChatMessages' AND index_name = 'idx_chat_messages_timestamp'
    ) THEN
        CREATE INDEX idx_chat_messages_timestamp ON ChatMessages (timestamp);
    END IF;

    -- Sales Table Indexes (Optional)
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.statistics
        WHERE table_schema = DATABASE() AND table_name = 'Sales' AND index_name = 'idx_sales_customer_product'
    ) THEN
        CREATE INDEX idx_sales_customer_product ON Sales (customer_id, product_id);
    END IF;

    -- Logs Table Index
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.statistics
        WHERE table_schema = DATABASE() AND table_name = 'Logs' AND index_name = 'idx_logs_type'
    ) THEN
        CREATE INDEX idx_logs_type ON Logs (log_type);
    END IF;

END;

